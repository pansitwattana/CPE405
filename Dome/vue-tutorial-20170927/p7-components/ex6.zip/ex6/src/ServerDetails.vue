<template>
    <div id='detail'>
        <div class="col-xs-12 col-sm-6">
            <p>Server Details are currently not updated</p>
        </div>
    </div>
</template>

<script>
export default {
    name: 'detail'
}
</script>

