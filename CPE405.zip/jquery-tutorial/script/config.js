dataChart = {
  label: ["John","Jan","Jib","Jack","Jim"],
  count: [10,20,30,40,50]
}
