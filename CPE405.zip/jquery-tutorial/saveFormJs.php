<?php
  $data = $_POST["data"];

  if($data)
    echo "true";
  else
    echo "false";
?>
