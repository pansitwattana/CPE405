<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title> .:: Hello! ::. </title>
    <!-- <link rel="stylesheet" type="text/css" href="style/stylesheet-compiled.css?<?php echo rand(0,999); ?>"> -->
    <link rel="stylesheet" type="text/css" href="index.css">
  </head>

  <body>
    <label>Hello World!</label>
    <p>I want to be friendly.</p>
  </body>
  <script type="text/javascript" src="script/script.js?<?php echo rand(0,999); ?>"></script>
</html>
